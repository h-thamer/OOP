/*
Haitham Thamer 756124
ucen Manchester
*/

public abstract class PlayerDecorator extends Player
{

   public abstract String getWeaponCrate();
}
