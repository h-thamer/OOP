/*
Haitham Thamer 756124
ucen Manchester
*/

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class SPSG extends Application {

    private Pane root = new Pane();

    private double t = 0;

    int enemyHealth=100;
    int soldierHealth=100;

    Label health;

    String cho;
    String Soldierweapon;
    String Enemyweapon;

    Player soldier;
    Player Enemy;
    private Sprite player;
    //private Sprite enemy;


    //private Sprite player = soldier.CreatePlayer(300, 650, 40, 40, "player", Color.BLUE);

    private Parent createContent()
    {

         health=new Label("Soldier Health: 100");
        health.setLayoutY(250);
        health.setLayoutX(50);
        health.setPrefWidth(120);
        health.setPrefHeight(25);

        switch (cho)
        {
            case "Easy":
                soldier=new Soldier();
                soldier=new Ammo(soldier);
                soldier=new Gun(soldier);
                soldier=new ArrowHead(soldier);
                soldier=new HandGrenade(soldier);
                Soldierweapon=soldier.getWeaponCrate();
                player = soldier.CreatePlayer(200, 650, 40, 40, "player", Color.BLUE);
                shoot(player);
                arrohead(player);
                handgrenade(player);
                Enemy=new Enemy();
                Enemy=new Gun(Enemy);
                Enemyweapon=Enemy.getWeaponCrate();
                nextLevel(2);

                break;
            case "Medium":
                soldier=new Soldier();
                soldier=new Ammo(soldier);
                soldier=new Gun(soldier);
                soldier=new ArrowHead(soldier);
                Soldierweapon=soldier.getWeaponCrate();
                player = new Sprite(200, 650, 40, 40, "player", Color.BLUE);
                shoot(player);
                arrohead(player);
                Enemy=new Enemy();
                Enemy=new Ammo(Enemy);
                Enemy=new Gun(Enemy);
                Enemy=new ArrowHead(Enemy);
                Enemyweapon=Enemy.getWeaponCrate();
                nextLevel(4);

                break;
            case "Hard":
                soldier=new Soldier();
                soldier=new Ammo(soldier);
                soldier=new Gun(soldier);
                Soldierweapon=soldier.getWeaponCrate();
                player = new Sprite(200, 650, 40, 40, "player", Color.BLUE);
                shoot(player);
                arrohead(player);
                Enemy=new Enemy();
                Enemy=new Ammo(Enemy);
                Enemy=new Gun(Enemy);
                Enemy=new HandGrenade(Enemy);
                Enemy=new ArrowHead(Enemy);
                Enemyweapon=Enemy.getWeaponCrate();
                nextLevel(5);

                break;

        }
        root.setPrefSize(600, 700);

        root.getChildren().add(player);

        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
            }
        };

        timer.start();



        return root;
    }

    private void nextLevel(int number) {
        for (int i = 0; i < number; i++)
        {

            Sprite enemy = new Sprite(90 + i*100, 150, 30, 30, "enemy", Color.RED);

            root.getChildren().add(enemy);
        }
    }

    private List<Sprite> sprites() {
        return root.getChildren().stream().map(n -> (Sprite)n).collect(Collectors.toList());
    }

    private void update()
    {

        t += 0.016;

        sprites().forEach(s -> {
            switch (s.type) {
                case "enemybullet":
                    s.moveDown();

                    if (s.getBoundsInParent().intersects(player.getBoundsInParent()))
                    {
                        if(soldierHealth<=0)
                        {
                            player.dead = true;
                            s.dead = true;
                        }
                        else
                        {
                            soldierHealth=soldierHealth-15;
                            health.setText("Soldier Health: "+Integer.toString(soldierHealth));
                        }

                    }
                    break;

                case "playerbullet":
                    s.moveUp();

                    sprites().stream().filter(e -> e.type.equals("enemy")).forEach(enemy -> {
                        if (s.getBoundsInParent().intersects(enemy.getBoundsInParent())) {
                            enemy.dead = true;
                            s.dead = true;
                        }
                    });

                    break;
                case "playerarrowhead":
                    s.moveUp();

                    sprites().stream().filter(e -> e.type.equals("enemy")).forEach(enemy -> {
                        if (s.getBoundsInParent().intersects(enemy.getBoundsInParent())) {
                            enemy.dead = true;
                            s.dead = true;
                        }
                    });

                    break;
                case "playerhandgrenade":
                    s.moveUp();

                    sprites().stream().filter(e -> e.type.equals("enemy")).forEach(enemy -> {
                        if (s.getBoundsInParent().intersects(enemy.getBoundsInParent())) {
                            enemy.dead = true;
                            s.dead = true;
                        }
                    });

                    break;
                case "enemyarrowhead":
                    s.moveDown();

                    if (s.getBoundsInParent().intersects(player.getBoundsInParent())) {
                        if(soldierHealth<=0)
                        {
                            player.dead = true;
                            s.dead = true;
                        }
                        else
                        {
                            soldierHealth=soldierHealth-10;
                            health.setText("Soldier Health: "+Integer.toString(soldierHealth));
                        }
                    }
                    break;
                case "enemyhandgrenade":
                    s.moveDown();

                    if (s.getBoundsInParent().intersects(player.getBoundsInParent())) {
                        if(soldierHealth<=0)
                        {
                            player.dead = true;
                            s.dead = true;
                        }
                        else
                        {
                            soldierHealth=soldierHealth-30;
                            health.setText("Soldier Health: "+Integer.toString(soldierHealth));
                        }
                    }
                    break;

                case "enemy":

                    if (t > 2) {
                        if (Math.random() < 0.3) {
                            shoot(s);
                        }
//                        if(Math.random()>0.3 && list.contains("HandGrenade"))
//                        {
//                            handgrenade(s);
//                        }
//                        if(Math.random()>0.5 && list.contains("ArrowHead"))
//                        {
//                            arrohead(s);
//                        }
                    }

                    break;
            }
        });

        root.getChildren().removeIf(n -> {
            Sprite s = (Sprite) n;
            return s.dead;
        });

        if (t > 2) {
            t = 0;
        }
    }

    private void shoot(Sprite who) {
        Sprite s = new Sprite((int) who.getTranslateX() + 20, (int) who.getTranslateY(), 5, 20, who.type + "bullet", Color.BLACK);
        root.getChildren().add(s);
    }
    private void arrohead(Sprite who) {
        Sprite s = new Sprite((int) who.getTranslateX() + 20, (int) who.getTranslateY(), 5, 20, who.type + "arrowhead", Color.GOLD);

        root.getChildren().add(s);
    }

    private void handgrenade(Sprite who) {
        Sprite s = new Sprite((int) who.getTranslateX() + 20, (int) who.getTranslateY(), 5, 20, who.type + "handgrenade", Color.GOLD);

        root.getChildren().add(s);
    }

    @Override
    public void start(Stage stage) throws Exception
    {
        Pane messagePane=new Pane();
        Label messageLabel=new Label("Select Your Level");
        messageLabel.setPrefWidth(190);
        messageLabel.setPrefHeight(20);
        messageLabel.setLayoutX(250);
        messageLabel.setLayoutY(15);
        Button easy=new Button("Easy");
        easy.setLayoutY(70);
        easy.setLayoutX(150);
        easy.setPrefWidth(50);
        easy.setPrefHeight(25);

        Button medium=new Button("Medium");
        medium.setLayoutY(70);
        medium.setLayoutX(300);
        medium.setPrefWidth(70);
        medium.setPrefHeight(25);

        Button hard=new Button("Hard");
        hard.setLayoutY(70);
        hard.setLayoutX(450);
        hard.setPrefWidth(70);
        hard.setPrefHeight(25);

        EventHandler<ActionEvent> easy_btn=new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                cho="Easy";
                Scene scene = new Scene(createContent());
             System.out.println(Soldierweapon);
                String[] solArray=Soldierweapon.split(",");
                List<String> list = Arrays.asList(solArray);
                scene.setOnKeyPressed(e -> {
                    switch (e.getCode()) {
                        case A:
                            player.moveLeft();
                            break;
                        case D:
                            player.moveRight();
                            break;
                        case SPACE:
                            if(!player.dead)
                               shoot(player);
                        case G:
                            if(list.contains("HandGrenade"))
                            {
                                handgrenade(player);
                            }
                            break;
                        case H:

                            if(list.contains("ArrowHead"))
                            {
                                arrohead(player);

                            }
                            break;
                    }
                });
                stage.setScene(scene);
            }
        };
        easy.setOnAction(easy_btn);

        EventHandler<ActionEvent> medium_btn=new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                cho="Medium";
                Scene scene = new Scene(createContent());
                System.out.println(Soldierweapon);
                String[] solArray=Soldierweapon.split(",");
                List<String> list = Arrays.asList(solArray);
                scene.setOnKeyPressed(e -> {
                    switch (e.getCode()) {
                        case A:
                            player.moveLeft();
                            break;
                        case D:
                            player.moveRight();
                            break;
                        case SPACE:
                            if(!player.dead)
                                shoot(player);
                        case G:
                            if(list.contains("HandGrenade"))
                            {
                                handgrenade(player);
                            }
                            break;
                        case H:

                            if(list.contains("ArrowHead"))
                            {
                                arrohead(player);

                            }
                            break;
                    }
                });
                stage.setScene(scene);
            }
        };
        medium.setOnAction(medium_btn);

        EventHandler<ActionEvent> hard_btn=new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                cho="Hard";
                Scene scene = new Scene(createContent());
                System.out.println(Soldierweapon);
                String[] solArray=Soldierweapon.split(",");
                List<String> list = Arrays.asList(solArray);
                scene.setOnKeyPressed(e -> {
                    switch (e.getCode()) {
                        case A:
                            player.moveLeft();
                            break;
                        case D:
                            player.moveRight();
                            break;
                        case SPACE:
                            if(!player.dead)
                                shoot(player);
                        case G:
                            if(list.contains("HandGrenade"))
                            {
                                handgrenade(player);
                            }
                            break;
                        case H:

                            if(list.contains("ArrowHead"))
                            {
                                arrohead(player);

                            }
                            break;
                    }
                });
                stage.setScene(scene);
            }
        };
        hard.setOnAction(hard_btn);
        messagePane.getChildren().addAll(messageLabel,easy,medium,hard);



        Scene messageScene=new Scene(messagePane,600,200);
        stage.setScene(messageScene);
        stage.show();
    }

    public static class Sprite extends Rectangle {
        boolean dead = false;
        final String type;

        Sprite(int x, int y, int w, int h, String type, Color color) {
            super(w, h, color);

            this.type = type;
            setTranslateX(x);
            setTranslateY(y);
        }

        void moveLeft() {
            setTranslateX(getTranslateX() - 5);
        }

        void moveRight() {
            setTranslateX(getTranslateX() + 5);
        }

        void moveUp() {
            setTranslateY(getTranslateY() - 5);
        }

        void moveDown() {
            setTranslateY(getTranslateY() + 5);
        }
    }

    public static void main(String[] args)
    {


        launch(args);
    }
}