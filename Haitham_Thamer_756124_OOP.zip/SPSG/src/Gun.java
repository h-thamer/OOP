/*
Haitham Thamer 756124
ucen Manchester
*/
import javafx.scene.paint.Color;

public class Gun extends PlayerDecorator {

    Player player;
    public Gun(Player player)
    {
        this.player=player;
    }
    @Override
    public String getWeaponCrate()
    {
        return player.getWeaponCrate()+",Gun";
    }

    @Override
    SPSG.Sprite CreatePlayer(int x, int y, int w, int h, String type, Color color) {
        return player.CreatePlayer(x,y,w,h,type,color);
    }
}
