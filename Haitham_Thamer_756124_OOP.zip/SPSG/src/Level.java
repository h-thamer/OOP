/*
Haitham Thamer 756124
ucen Manchester
*/

public class Level
{

    private static Level level;

    private Level()
    {

    }

    public static Level getInstance()
    {
        if(level==null)
        {
            level=new Level();
        }
        return level;
    }


}
