/*
Haitham Thamer 756124
ucen Manchester
*/

import javafx.scene.paint.Color;

public class Enemy extends Player
{
    public Enemy()
    {
        weaponCrate="Enemy Weapon Crate";
    }

    @Override
    public SPSG.Sprite CreatePlayer(int x, int y, int w, int h, String type, Color color)
    {

            SPSG.Sprite enemy=new SPSG.Sprite(x ,y, w, h, type, color);
            return  enemy;
    }
}
