/*
Haitham Thamer 756124
ucen Manchester
*/
import javafx.scene.paint.Color;

public abstract class Player
{
    String weaponCrate="Weapon Crate";
    String playerType="Unknown";

    abstract SPSG.Sprite CreatePlayer(int x, int y, int w, int h, String type, Color color);

    public String getWeaponCrate()
    {
        return  weaponCrate;
    }
}
