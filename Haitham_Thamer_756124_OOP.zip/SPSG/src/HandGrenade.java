/*
Haitham Thamer 756124
ucen Manchester
*/

import javafx.scene.paint.Color;

public class HandGrenade extends PlayerDecorator {

    Player player;
    public HandGrenade(Player player)
    {
        this.player=player;
    }

    @Override
    public String getWeaponCrate()
    {
        return player.getWeaponCrate()+",HandGrenade";
    }

    @Override
    SPSG.Sprite CreatePlayer(int x, int y, int w, int h, String type, Color color) {
        return player.CreatePlayer(x,y,w,h,type,color);
    }
}
