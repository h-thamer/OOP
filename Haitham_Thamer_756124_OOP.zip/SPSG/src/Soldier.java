/*
Haitham Thamer 756124
ucen Manchester
*/

import javafx.scene.paint.Color;

public class Soldier extends Player
{
    public Soldier()
    {
        weaponCrate="Solider Weapon Crate";
    }

    @Override
    public SPSG.Sprite CreatePlayer(int x, int y, int w, int h, String type, Color color)
    {

        SPSG.Sprite enemy=new SPSG.Sprite(300, 650, 40, 40, "player", Color.BLUE);
        return  enemy;
    }
}
